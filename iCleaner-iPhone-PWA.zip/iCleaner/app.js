const $ = (id) => document.getElementById(id);
const fileInput = $("fileInput"), mediaInput = $("mediaInput");
let toastTimer;
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2800)}
function formatBytes(bytes){if(!Number.isFinite(bytes))return "—";if(bytes===0)return "0 o";const units=["o","Ko","Mo","Go","To"];const i=Math.min(Math.floor(Math.log(bytes)/Math.log(1024)),units.length-1);return (bytes/Math.pow(1024,i)).toLocaleString("fr-FR",{maximumFractionDigits:1})+" "+units[i]}
async function refreshStorage(){if(!navigator.storage?.estimate){$("used").textContent="N/D";$("quota").textContent="Mesure non disponible";$("ring").style.background="conic-gradient(#39445b 0deg 360deg)";return}
 try{const e=await navigator.storage.estimate();const usage=e.usage||0,quota=e.quota||0;const pct=quota?Math.min(100,usage/quota*100):0;$("used").textContent=formatBytes(usage);$("quota").textContent=quota?`${formatBytes(quota)} de quota web estimé`:"Quota indisponible";$("ring").style.background=`conic-gradient(#9679ff 0deg,#4c9fff ${pct*3.6}deg,#28334a ${pct*3.6}deg 360deg)`}catch{$("used").textContent="N/D";$("quota").textContent="Estimation indisponible"}}
$("refreshStorage").addEventListener("click",refreshStorage);
$("pickFiles").addEventListener("click",()=>fileInput.click());
$("pickMedia").addEventListener("click",()=>mediaInput.click());
fileInput.addEventListener("change",()=>analyze([...fileInput.files]));
mediaInput.addEventListener("change",()=>analyze([...mediaInput.files]));
async function hashFile(file){const buffer=await file.arrayBuffer();const digest=await crypto.subtle.digest("SHA-256",buffer);return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,"0")).join("")}
async function analyze(files){
 if(!files.length)return;
 toast("Analyse locale en cours…");
 const rows=[];const hashes=new Map();
 for(const f of files){
   let hash="";try{hash=await hashFile(f)}catch{}
   const duplicate=hash?hashes.has(hash):false;
   if(hash&&!duplicate)hashes.set(hash,f.name);
   rows.push({name:f.name,size:f.size,type:f.type||"Fichier",duplicate});
 }
 renderResults(rows);fileInput.value="";mediaInput.value="";toast("Analyse terminée. Aucun fichier n’a été modifié.");
}
function renderResults(rows){
 const total=rows.reduce((s,r)=>s+r.size,0),duplicates=rows.filter(r=>r.duplicate);
 $("emptyState").hidden=true;$("results").hidden=false;$("fileCount").textContent=`${rows.length} fichier${rows.length>1?"s":""}`;
 const sorted=[...rows].sort((a,b)=>b.size-a.size);
 $("results").innerHTML=`<div class="result-summary"><div class="stat"><strong>${rows.length}</strong><span>Fichiers analysés</span></div><div class="stat"><strong>${formatBytes(total)}</strong><span>Taille cumulée</span></div><div class="stat"><strong>${duplicates.length}</strong><span>Doublons exacts</span></div></div><div class="result-list">${sorted.map(r=>`<div class="file-row"><div><div class="file-name">${escapeHTML(r.name)}</div>${r.duplicate?'<div class="duplicate-label">Doublon exact détecté</div>':`<div class="file-meta">${escapeHTML(r.type)}</div>`}</div><div class="file-meta">${formatBytes(r.size)}</div></div>`).join("")}</div>`;
}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
refreshStorage();