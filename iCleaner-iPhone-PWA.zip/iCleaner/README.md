# iCleaner

Application web progressive (PWA) open source, conçue pour Safari sur iPhone.

## Fonctions disponibles
- Sélection locale de fichiers ou médias via le sélecteur iOS.
- Calcul de la taille cumulée, tri par taille et détection des doublons binaires exacts (SHA-256).
- Estimation du quota de stockage du navigateur, si l'API est disponible.
- Mise en cache hors ligne après le premier chargement.

## Limites iOS importantes
iCleaner n'est pas une application native et ne peut pas inspecter tout l'iPhone. Le sélecteur iOS ne donne accès qu'aux éléments que l'utilisateur choisit. L'estimation `navigator.storage.estimate()` concerne le stockage du site/PWA, pas la capacité totale de l'iPhone. iOS ne permet pas à une PWA de vider les caches d'autres apps, d'accéder librement à leurs données, ni de supprimer automatiquement des photos. La suppression doit être faite par l'utilisateur dans Photos ou Fichiers. L'API Battery n'est pas disponible de façon fiable dans Safari iOS.

## Installer sur iPhone
1. Hébergez le dossier sur une adresse HTTPS publique (GitHub Pages, Netlify ou votre propre hébergement).
2. Ouvrez l'URL dans **Safari** sur l'iPhone.
3. Touchez **Partager** puis **Sur l'écran d'accueil**.
4. Activez **Ouvrir en tant qu'app web** si l'option apparaît, puis touchez **Ajouter**.

Un fichier ZIP seul ne peut pas être installé directement comme une app iPhone. Il faut d'abord héberger ces fichiers en HTTPS.

## Hébergement gratuit avec GitHub Pages
1. Créez un dépôt public GitHub nommé `icleaner`.
2. Téléversez tous les fichiers et le dossier `icons`.
3. Dans **Settings → Pages**, choisissez **Deploy from a branch**, sélectionnez `main` et `/ (root)`, puis enregistrez.
4. Attendez la publication, puis ouvrez l'URL Pages dans Safari sur l'iPhone.

## Licence
MIT — voir `LICENSE`.
